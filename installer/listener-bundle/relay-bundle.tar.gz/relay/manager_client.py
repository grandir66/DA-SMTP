"""Client HTTP verso il manager (backend pluggabile).

Espone l'astrazione `ManagerBackend` che il resto del codice usa per dialogare con il manager
remoto. L'implementazione `StormshieldManagerBackend` è quella di default e parla con gli
endpoint `/api/v1/relay/*` dello Stormshield Manager. Il design plug-in permette di sostituire
il backend con altri (es. un manager diverso, una sorgente locale per uso standalone) senza
toccare listener/scheduler/pipeline.
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

import httpx

from relay.config import ManagerConfig

logger = logging.getLogger(__name__)


@dataclass
class CustomersPayload:
    synced_at: str
    customers: list[dict[str, Any]] = field(default_factory=list)
    etag: str | None = None


@dataclass
class RulesPayload:
    synced_at: str
    rules: list[dict[str, Any]] = field(default_factory=list)
    etag: str | None = None


@dataclass
class RoutesPayload:
    synced_at: str
    routes: list[dict[str, Any]] = field(default_factory=list)
    etag: str | None = None


@dataclass
class SettingsPayload:
    synced_at: str
    settings: dict[str, Any] = field(default_factory=dict)
    etag: str | None = None


@dataclass
class DomainRoutingPayload:
    synced_at: str
    domains: list[dict[str, Any]] = field(default_factory=list)
    etag: str | None = None


@dataclass
class TemplatesPayload:
    synced_at: str
    templates: list[dict[str, Any]] = field(default_factory=list)
    etag: str | None = None


@dataclass
class TicketResult:
    ok: bool
    ticket_id: str | None
    status_code: int
    response_body: str
    error: str | None = None


@dataclass
class AuthCodeResult:
    ok: bool
    code: str | None = None
    valid_until: str | None = None
    code_id: int | None = None
    error: str | None = None


@dataclass
class AggregationsPayload:
    synced_at: str
    aggregations: list[dict[str, Any]] = field(default_factory=list)
    etag: str | None = None


@dataclass
class CustomerGroupsPayload:
    """Gruppi clienti + membership (admin migration 018).

    Cached lato listener per il match `match_customer_groups` nelle regole.
    """
    synced_at: str
    groups: list[dict[str, Any]] = field(default_factory=list)
    members: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class PrivacyBypassPayload:
    """Lista privacy-bypass attiva (migration 011 admin).

    Indirizzi e domini che NON devono essere elaborati dal rule engine,
    dalle aggregations o dall'auto-reply per ragioni GDPR/operative.
    Pre-controllo lato listener PRIMA del rule engine.
    """
    synced_at: str
    from_emails: list[str] = field(default_factory=list)
    to_emails: list[str] = field(default_factory=list)
    from_domains: list[str] = field(default_factory=list)
    to_domains: list[str] = field(default_factory=list)
    etag: str | None = None


class ManagerError(Exception):
    """Errore comunicazione manager (rete, auth, schema invalido)."""


class ManagerBackend(ABC):
    @abstractmethod
    def fetch_active_customers(self) -> CustomersPayload: ...

    @abstractmethod
    def fetch_active_rules(self) -> RulesPayload: ...

    @abstractmethod
    def fetch_active_routes(self) -> RoutesPayload: ...

    @abstractmethod
    def fetch_active_settings(self) -> SettingsPayload: ...

    @abstractmethod
    def fetch_active_domain_routing(self) -> DomainRoutingPayload: ...

    @abstractmethod
    def fetch_active_templates(self) -> TemplatesPayload: ...

    def fetch_active_customer_groups(self) -> CustomerGroupsPayload:
        # Fallback: backend pre-migration-018 ignorano i gruppi.
        return CustomerGroupsPayload(synced_at="")

    @abstractmethod
    def submit_events(self, events: list[dict[str, Any]]) -> dict[str, Any]: ...

    @abstractmethod
    def submit_ticket(self, payload: dict[str, Any]) -> TicketResult: ...

    @abstractmethod
    def issue_auth_code(self, *, codcli: str | None, rule_id: int | None,
                        ttl_hours: int, note: str | None = None) -> AuthCodeResult: ...

    @abstractmethod
    def fetch_active_aggregations(self) -> AggregationsPayload: ...

    @abstractmethod
    def replicate_occurrence(self, agg_id: int, payload: dict[str, Any]) -> bool: ...

    def fetch_active_privacy_bypass(self) -> PrivacyBypassPayload:
        """Default implementation per backend che non ancora implementano la
        migrazione 011. Ritorna lista vuota (no bypass) — il listener si
        comporta come pre-011 (rule engine sempre attivo)."""
        return PrivacyBypassPayload(synced_at="", from_emails=[], to_emails=[],
                                    from_domains=[], to_domains=[])


class StormshieldManagerBackend(ManagerBackend):
    """Backend che parla con Stormshield Manager via /api/v1/relay/* + /api/v1/tickets/."""

    def __init__(self, cfg: ManagerConfig):
        self._cfg = cfg
        if cfg.ca_bundle:
            verify: bool | str = cfg.ca_bundle
        elif not cfg.verify_tls:
            verify = False
        else:
            verify = True
        self._client = httpx.Client(
            base_url=cfg.base_url.rstrip("/"),
            timeout=cfg.timeout_sec,
            headers={
                "X-API-Key": cfg.api_key,
                "User-Agent": "stormshield-smtp-relay/0.1",
                "Accept": "application/json",
            },
            verify=verify,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "StormshieldManagerBackend":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def _get_json(self, path: str) -> dict[str, Any]:
        try:
            resp = self._client.get(path)
        except httpx.HTTPError as exc:
            raise ManagerError(f"Errore rete su GET {path}: {exc}") from exc
        if resp.status_code == 401:
            raise ManagerError(f"Autenticazione fallita su {path} (API key invalida)")
        if resp.status_code >= 400:
            raise ManagerError(f"GET {path} ha risposto {resp.status_code}: {resp.text[:200]}")
        try:
            data = resp.json()
        except ValueError as exc:
            raise ManagerError(f"Risposta non JSON da {path}: {exc}") from exc
        if not isinstance(data, dict):
            raise ManagerError(f"Schema risposta invalido da {path}: atteso dict, ottenuto {type(data).__name__}")
        return data

    def fetch_active_customers(self) -> CustomersPayload:
        data = self._get_json("/api/v1/relay/customers/active")
        return CustomersPayload(
            synced_at=data.get("synced_at", ""),
            customers=list(data.get("customers", [])),
        )

    def fetch_active_rules(self) -> RulesPayload:
        data = self._get_json("/api/v1/relay/rules/active")
        return RulesPayload(
            synced_at=data.get("synced_at", ""),
            rules=list(data.get("rules", [])),
        )

    def fetch_active_routes(self) -> RoutesPayload:
        data = self._get_json("/api/v1/relay/routes/active")
        return RoutesPayload(
            synced_at=data.get("synced_at", ""),
            routes=list(data.get("routes", [])),
        )

    def fetch_active_settings(self) -> SettingsPayload:
        data = self._get_json("/api/v1/relay/settings/active")
        return SettingsPayload(
            synced_at=data.get("synced_at", ""),
            settings=dict(data.get("settings", {})),
        )

    def fetch_active_domain_routing(self) -> DomainRoutingPayload:
        data = self._get_json("/api/v1/relay/domain-routing/active")
        return DomainRoutingPayload(
            synced_at=data.get("synced_at", ""),
            domains=list(data.get("domains", [])),
        )

    def fetch_active_privacy_bypass(self) -> PrivacyBypassPayload:
        try:
            data = self._get_json("/api/v1/relay/privacy-bypass/active")
        except ManagerError as exc:
            # 404 atteso su manager pre-migration-011 → fallback safe
            if "404" in str(exc):
                return PrivacyBypassPayload(synced_at="")
            raise
        return PrivacyBypassPayload(
            synced_at=data.get("synced_at", ""),
            from_emails=[s.lower() for s in data.get("from", []) if s],
            to_emails=[s.lower() for s in data.get("to", []) if s],
            from_domains=[s.lower() for s in data.get("from_domains", []) if s],
            to_domains=[s.lower() for s in data.get("to_domains", []) if s],
        )

    def fetch_active_customer_groups(self) -> CustomerGroupsPayload:
        try:
            data = self._get_json("/api/v1/relay/customer-groups/active")
        except ManagerError as exc:
            # 404 atteso su manager pre-migration-018 → fallback safe
            if "404" in str(exc):
                return CustomerGroupsPayload(synced_at="")
            raise
        return CustomerGroupsPayload(
            synced_at=data.get("synced_at", ""),
            groups=list(data.get("groups", [])),
            members=list(data.get("members", [])),
        )

    def fetch_active_templates(self) -> TemplatesPayload:
        data = self._get_json("/api/v1/relay/templates/active")
        return TemplatesPayload(
            synced_at=data.get("synced_at", ""),
            templates=list(data.get("templates", [])),
        )

    def submit_events(self, events: list[dict[str, Any]]) -> dict[str, Any]:
        if not events:
            return {"accepted": 0, "duplicates": 0}
        try:
            resp = self._client.post("/api/v1/relay/events", json={"events": events})
        except httpx.HTTPError as exc:
            raise ManagerError(f"Errore rete su POST events: {exc}") from exc
        if resp.status_code >= 400:
            raise ManagerError(f"POST events ha risposto {resp.status_code}: {resp.text[:200]}")
        try:
            return resp.json()
        except ValueError:
            return {"accepted": len(events), "duplicates": 0}

    def submit_ticket(self, payload: dict[str, Any]) -> TicketResult:
        try:
            resp = self._client.post("/api/v1/tickets/", json=payload)
        except httpx.HTTPError as exc:
            return TicketResult(ok=False, ticket_id=None, status_code=0, response_body="", error=str(exc))
        body = resp.text[:1000]
        if resp.status_code >= 200 and resp.status_code < 300:
            try:
                data = resp.json()
                ticket_id = str(data.get("ticket_id") or data.get("id") or "")
            except ValueError:
                ticket_id = ""
            return TicketResult(ok=True, ticket_id=ticket_id or None, status_code=resp.status_code, response_body=body)
        return TicketResult(
            ok=False,
            ticket_id=None,
            status_code=resp.status_code,
            response_body=body,
            error=f"HTTP {resp.status_code}",
        )

    def issue_auth_code(self, *, codcli: str | None, rule_id: int | None,
                        ttl_hours: int, note: str | None = None) -> AuthCodeResult:
        try:
            resp = self._client.post(
                "/api/v1/relay/auth-codes",
                json={
                    "codice_cliente": codcli,
                    "rule_id": rule_id,
                    "ttl_hours": int(ttl_hours),
                    "note": note,
                },
            )
        except httpx.HTTPError as exc:
            return AuthCodeResult(ok=False, error=f"network: {exc}")
        if resp.status_code >= 200 and resp.status_code < 300:
            try:
                data = resp.json()
                if data.get("ok"):
                    return AuthCodeResult(
                        ok=True,
                        code=data.get("code"),
                        valid_until=data.get("valid_until"),
                        code_id=data.get("id"),
                    )
                return AuthCodeResult(ok=False, error=data.get("error") or "manager returned ok=false")
            except ValueError:
                return AuthCodeResult(ok=False, error="risposta non-JSON")
        return AuthCodeResult(ok=False, error=f"HTTP {resp.status_code}: {resp.text[:200]}")

    def fetch_active_aggregations(self) -> AggregationsPayload:
        data = self._get_json("/api/v1/relay/aggregations/active")
        return AggregationsPayload(
            synced_at=data.get("synced_at", ""),
            aggregations=list(data.get("aggregations", [])),
        )

    def replicate_occurrence(self, agg_id: int, payload: dict[str, Any]) -> bool:
        try:
            resp = self._client.post(f"/api/v1/relay/aggregations/{agg_id}/occurrence", json=payload)
        except httpx.HTTPError as exc:
            logger.warning("replicate_occurrence rete: %s", exc)
            return False
        if resp.status_code >= 200 and resp.status_code < 300:
            return True
        logger.warning("replicate_occurrence HTTP %s: %s", resp.status_code, resp.text[:200])
        return False


def build_backend(cfg: ManagerConfig) -> ManagerBackend:
    """Factory: sceglie l'implementazione in base a `cfg.backend`. Default 'stormshield'."""
    if cfg.backend == "stormshield":
        return StormshieldManagerBackend(cfg)
    raise ValueError(f"Backend manager '{cfg.backend}' non supportato in questa versione")
